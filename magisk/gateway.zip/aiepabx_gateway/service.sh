#!/system/bin/sh

# Wait for boot complete
until [ "$(getprop sys.boot_completed)" == 1 ]; do
    sleep 1
done

# Grant required permissions to app
PACKAGE="com.deepshetye.AIEPABX"

pm grant $PACKAGE android.permission.CAPTURE_AUDIO_OUTPUT
pm grant $PACKAGE android.permission.MODIFY_PHONE_STATE
pm grant $PACKAGE android.permission.READ_PRECISE_PHONE_STATE
pm grant $PACKAGE android.permission.ANSWER_PHONE_CALLS
pm grant $PACKAGE android.permission.CALL_PHONE
pm grant $PACKAGE android.permission.READ_PHONE_STATE

# Set app to not be optimized (keep alive)
dumpsys deviceidle whitelist +$PACKAGE

# Log success
echo "[AI-EPABX] Permissions granted successfully" >> /data/local/tmp/aiepabx_permissions.log
